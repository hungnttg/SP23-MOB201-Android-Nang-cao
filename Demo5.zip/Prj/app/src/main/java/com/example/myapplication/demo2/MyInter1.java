package com.example.myapplication.demo2;

public interface MyInter1 {
    public String getDataCallback(String msg);
}
