package com.example.myapplication.demo5n;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class MyXML {
    //1. Lay ve 1 tai lieu xml
    public Document getDocument(String xml) throws IOException, SAXException {
        Document document=null;
        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();//doi tuong tao 1 tai lieu trong
        DocumentBuilder builder=null;
        try {
            builder=factory.newDocumentBuilder();//bat dau tao tai lieu
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        InputSource inputSource=new InputSource();//chuan bi nguon du lieu
        inputSource.setCharacterStream(new StringReader(xml));//doc tai lieu
        inputSource.setEncoding("UTF-8");//dinh dang tai lieu
        document=builder.parse(inputSource);//chuyen du lieu vao tai lieu
        return document;
    }
    //2. Lay ve text cua node con
    public String getValue(Element node,String name)
    {
        String result="";
        NodeList nodeList=node.getElementsByTagName(name);//lay ve danh sach cac the
        result=getTextOfNode(nodeList.item(0));//lay ve text cua node dau tien
        return result;
    }
    //ham phu tro: lay text cua node
    private String getTextOfNode(Node item) {
        Node con;
        if(item!=null)
        {
            if(item.hasChildNodes())//neu no co thanh phan con
            {
                for(con=item.getFirstChild();con!=null;con=con.getNextSibling())
                {
                    if(con.getNodeType()==Node.TEXT_NODE)
                    {
                        return con.getNodeValue();
                    }
                }
            }
        }
        return "";
    }

}
