package com.example.myapplication.demo5n;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.myapplication.R;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Demo5nMainActivity extends AppCompatActivity {
    ListView listView;
    List<String> lsTitle=new ArrayList<>();
    List<String> lsLink=new ArrayList<>();
    ArrayAdapter<String> arrayAdapter;
    Intent intent;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo5n_main);
        listView=findViewById(R.id.demo5nLv);
        //bat dau doc du lieu
        new MyAsyn1().execute("https://ngoisao.vnexpress.net/rss/showbiz.rss");
        arrayAdapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,lsTitle);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String link= lsLink.get(i);//lay ve link
                intent=new Intent(Demo5nMainActivity.this,Demo5nDetailMainActivity.class);
                intent.putExtra("linksent",link);
                startActivity(intent);
            }
        });
    }
    public class MyAsyn1 extends AsyncTask<String,Void,String>
    {
        //lay du lieu tu server
        @Override
        protected String doInBackground(String... strings) {
            StringBuilder stringBuilder=new StringBuilder();//doi tuong chua du lieu (kho)
            try {
                URL url=new URL(strings[0]); //duong link du lieu
                //luong doc
                InputStreamReader reader
                        =new InputStreamReader(url.openConnection().getInputStream());
                //bo dem
                BufferedReader bufferedReader=new BufferedReader(reader);
                //doc du lieu theo tung dong
                String line="";
                while ((line=bufferedReader.readLine())!=null)//neu van con du lieu
                {
                    stringBuilder.append(line);//dua vao kho du lieu
                }
                return stringBuilder.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        //tra du lieu ve client
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            MyXML myXML=new MyXML();
            try {
                Document document=myXML.getDocument(s);//lay tai lieu duoc chuyen tu server
                //lay ve danh sach cac node
                NodeList nodeList=document.getElementsByTagName("item");
                String title="";
                String link="";
                for(int i=0;i<nodeList.getLength();i++)
                {
                    Element element=(Element) nodeList.item(i);//lay ve item i
                    //lay ve title va link
                    title=myXML.getValue(element,"title");
                    lsTitle.add(title);//dua vao danh sach
                    link=myXML.getValue(element,"link");
                    lsLink.add(link);
                }
                arrayAdapter.notifyDataSetChanged();//cap nhat vao listview
            } catch (IOException e) {
                e.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            }
        }
    }
}