package com.example.myapplication.demo5n;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.myapplication.R;
public class Demo5nDetailMainActivity extends AppCompatActivity {

    WebView webView;
    Intent intent;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo5n_detail_main);
        webView=findViewById(R.id.demo5nDetailWebview);
        intent=getIntent();
        String link=intent.getStringExtra("linksent");
        webView.loadUrl(link);
        webView.setWebViewClient(new WebViewClient());
    }
}