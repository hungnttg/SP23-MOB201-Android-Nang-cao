package com.example.myapplication.demo1;

import android.app.IntentService;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyService3 extends IntentService {
    public MyService3() {
        super("MyService3");
    }
    int count=0;
    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        //lay ve ky tu truyen vao
        char c1=intent.getCharExtra("char",'0');
        //lay ve chuoi truyen vao
        String check=intent.getStringExtra("check");
        count=demKyTu(check,c1);//dem ky tu va tra ve count
    }

    @Override
    public void onDestroy() {
        Toast.makeText(this,"So ky tu la: "+count,Toast.LENGTH_LONG).show();
        Toast.makeText(this,"Huy service",Toast.LENGTH_LONG).show();
        super.onDestroy();
    }
    public int demKyTu(String str,char c)
    {
        int dem=0;
        for(int i=0;i<str.length();i++)
        {
            if(str.charAt(i)==c)//o vi tri thu i ma co ky tu c
            {
                dem++;
            }
        }
        return dem;
    }
}
